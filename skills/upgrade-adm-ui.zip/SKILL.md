---
name: upgrade-adm-ui
description: Refactor Korean university fund admin page PHP files to apply Figma design system while preserving existing layout structure. Use when modernizing Gnuboard-based admin interfaces without breaking existing CSS selectors and layout.
---

# Upgrade Admin UI Skill

## Purpose

This skill provides a systematic workflow for refactoring admin page PHP file styles to apply the Changwon National University Fund Figma design system. The skill ensures UI consistency across admin pages while preserving the existing layout structure defined in `admin.css`.

## When to Use This Skill

Use this skill when:
- User requests to modernize or refactor admin page UI styles
- User mentions applying Figma design, design system, or brand guidelines to admin pages
- User asks to improve or unify admin page appearance
- User requests to upgrade specific admin pages (member list, order list, fund management, etc.)
- User provides admin page file paths and asks for style improvements

Do NOT use this skill when:
- User wants to restructure the HTML layout or change semantic structure
- User asks to modify backend PHP logic or database queries
- User requests frontend public pages (not admin pages)

## Core Principles

### 1. Preserve Existing Layout Structure

**CRITICAL**: The existing CSS layout in `admin.css` MUST NOT be modified. This includes:
- Layout selectors (`.local_ov01`, `.local_sch01`, `.tbl_head01`, etc.)
- Grid and flexbox structures
- Container dimensions and positioning
- GNB and header layout

### 2. Override Styles Only

Apply design system styles by:
- Creating or updating `cwnu-admin-override.css`
- Using CSS specificity to override default styles
- Applying design tokens (CSS variables) from the design system
- Keeping existing HTML class names intact

### 3. Use Design Tokens

Reference the design system variables:
- Colors: `--cwnu-primary-1`, `--cwnu-primary-2`, `--cwnu-primary-bg`
- Spacing: `--cwnu-spacing-xs` through `--cwnu-spacing-7xl`
- Border radius: `--cwnu-radius-sm` through `--cwnu-radius-full`
- Shadows: `--cwnu-shadow-md`

## Workflow

### Step 1: Analyze the Target PHP File

Read the PHP file that needs style refactoring. Identify:
- Layout containers (`.local_ov01`, `.local_sch01`, etc.)
- Table structures (`.tbl_head01`, `.tbl_frm01`)
- Button groups (`.btn_ov02`, `.btn_fixed_top`)
- Form elements (`.frm_input`, `select`, `textarea`)
- Custom components (badges, pagination, cards)

### Step 2: Check Upgrade Priority

Consult `references/upgrade_element.md` to:
- Locate the file in the menu structure (Section 1)
- Identify applicable UI elements (Section 2-3)
- Determine upgrade priority (높음/중간/낮음)
- Review page-specific style requirements (Section 3)

Example priority mapping:
- **높음 (High)**: Buttons, input fields, table headers, search forms
- **중간 (Medium)**: Table rows, form sections, pagination
- **낮음 (Low)**: Checkbox cells, empty states

### Step 3: Reference Design System

Consult `references/upgrade_adm_from_figma.md` for:
- Color values (Section 1) - Primary colors, neutral colors, semantic colors
- Typography (Section 2) - Paperlogy for titles, Pretendard for body text
- Spacing (Section 3) - Padding and gap values
- Component styles (Section 6) - Buttons, badges, cards, forms, tables

When selecting styles:
- Use `--color-primary-01` (#003179) for primary actions and headers
- Use `--spacing-lg` (16px) for button padding
- Use `--radius-full` (1000px) for pill-shaped buttons
- Use `--text-bold-medium` for button text
- Use `.btn-primary` pattern for primary buttons

### Step 4: Check Existing Override File

Read `adm_cw/css/cwnu-admin-override.css` (if it exists) to:
- Understand what styles have already been applied
- Avoid duplicate selectors
- Maintain consistent patterns
- Identify gaps that need to be filled

If the file doesn't exist, prepare to create it.

### Step 5: Write Override Styles

Create or update `cwnu-admin-override.css` following these patterns:

#### Common Component Patterns

```css
/* Buttons */
.btn {
  border-radius: var(--cwnu-radius-full);
  padding: var(--cwnu-spacing-sm) var(--cwnu-spacing-lg);
  font-weight: 800;
  transition: all 0.2s ease;
}

.btn_01, .btn_submit {
  background-color: var(--cwnu-primary-1);
  color: var(--cwnu-white);
  border: 1px solid var(--cwnu-primary-1);
}

.btn_01:hover, .btn_submit:hover {
  background-color: var(--cwnu-primary-2);
  border-color: var(--cwnu-primary-2);
}

.btn_02 {
  background-color: var(--cwnu-white);
  color: var(--cwnu-primary-1);
  border: 1px solid var(--cwnu-primary-1);
}

/* Input Fields */
.frm_input {
  border: 1px solid var(--cwnu-gray-200);
  border-radius: var(--cwnu-radius-md);
  padding: var(--cwnu-spacing-sm) var(--cwnu-spacing-md);
  transition: border-color 0.2s ease;
}

.frm_input:focus {
  outline: none;
  border-color: var(--cwnu-primary-1);
  box-shadow: 0 0 0 3px rgba(0, 49, 121, 0.1);
}

/* Table Headers */
.tbl_head01 thead tr {
  background-color: var(--cwnu-primary-1);
  color: var(--cwnu-white);
}

.tbl_head01 tbody tr:hover {
  background-color: var(--cwnu-primary-bg);
}

/* Search Forms */
.local_sch01, .local_sch03 {
  background-color: var(--cwnu-white);
  border-radius: var(--cwnu-radius-lg);
  padding: var(--cwnu-spacing-xl);
  box-shadow: var(--cwnu-shadow-md);
  margin-bottom: var(--cwnu-spacing-xl);
}
```

#### Page-Specific Patterns

For pages with unique components (badges, special layouts), add specific styles:

```css
/* Member list badges */
.btn_ov01 {
  display: inline-flex;
  align-items: center;
  gap: var(--cwnu-spacing-sm);
  padding: var(--cwnu-spacing-sm) var(--cwnu-spacing-lg);
  border: 1px solid var(--cwnu-primary-1);
  border-radius: var(--cwnu-radius-full);
  background-color: var(--cwnu-white);
}

.ov_txt {
  font-size: 14px;
  color: var(--cwnu-primary-1);
}

.ov_num {
  font-size: 16px;
  font-weight: 800;
  color: var(--cwnu-primary-1);
}
```

### Step 6: Ensure CSS Variable Definitions

Verify that `cwnu-design-system.css` exists and is loaded. If not, create it with the full design token definitions from `references/upgrade_adm_from_figma.md` Section 9.

The file should be loaded in `admin.head.php` before `cwnu-admin-override.css`:

```html
<link rel="stylesheet" href="<?php echo G5_ADMIN_URL ?>/css/cwnu-design-system.css">
<link rel="stylesheet" href="<?php echo G5_ADMIN_URL ?>/css/cwnu-admin-override.css">
```

### Step 7: Test and Validate

After applying styles:
1. Verify that existing layout structure is intact
2. Check button interactions (hover, focus states)
3. Test form input focus states
4. Verify table styling (headers, rows, hover)
5. Ensure responsive behavior if applicable
6. Check for any CSS conflicts or broken styles

### Step 8: Document Changes

When presenting changes to the user:
- Summarize which components were styled
- List the key design tokens applied
- Note any page-specific customizations
- Provide the file path to modified CSS: [cwnu-admin-override.css](adm_cw/css/cwnu-admin-override.css)
- Mention if `cwnu-design-system.css` was created or updated

## Important Notes

### Do NOT Modify

- `admin.css` - Core layout file
- HTML structure or class names in PHP files
- Existing JavaScript functionality
- PHP backend logic

### Always Modify

- `cwnu-admin-override.css` - Override styles only
- Add new classes if needed, but prefer overriding existing ones

### Selector Specificity

When overriding styles, use the same or higher specificity:
- If original: `.tbl_head01 thead tr` → Use: `.tbl_head01 thead tr`
- Add `!important` only as a last resort
- Prefer contextual selectors over global tag selectors

### Design Token Prefixing

All custom CSS variables use `--cwnu-` prefix to avoid conflicts:
- `--cwnu-primary-1` not `--primary-1`
- `--cwnu-spacing-lg` not `--spacing-lg`

## Example Usage Scenarios

### Scenario 1: Refactor Member List Page

User request: "Upgrade the member list page UI to match our Figma design"

1. Read `member_list_bri.php`
2. Check `references/upgrade_element.md` Section 3.1 for member list elements
3. Identify: `.btn_ov01` badges, `.td_mbname`, `.mb_leave_msg` labels
4. Reference `references/upgrade_adm_from_figma.md` for badge and button styles
5. Update `cwnu-admin-override.css` with badge and table styles
6. Test member list page display

### Scenario 2: Unify Button Styles Across All Pages

User request: "Make all buttons consistent with the design system"

1. Read `references/upgrade_element.md` Section 2.4 for button priorities
2. Reference `references/upgrade_adm_from_figma.md` Section 6.1 for button styles
3. Update `cwnu-admin-override.css` with:
   - `.btn` base styles (pill shape, padding)
   - `.btn_01`, `.btn_submit` primary styles
   - `.btn_02` secondary styles
   - `.btn_03` small button styles
4. Test across multiple admin pages

### Scenario 3: Refactor Form Input Styles

User request: "Update all input fields to use the new design system"

1. Reference `references/upgrade_element.md` Section 2.3 for form elements
2. Reference `references/upgrade_adm_from_figma.md` for input field styles
3. Update `cwnu-admin-override.css` with:
   - `.frm_input` styles (border-radius, focus states)
   - `select` styles (appearance, arrow icon)
   - `textarea` styles
4. Test form pages (member form, order form, etc.)

## Reference Files

### `references/upgrade_adm_from_figma.md`

Complete Figma design system specification including:
- Color system (primary, neutral, semantic colors)
- Typography (Paperlogy, Pretendard fonts)
- Spacing system (padding, gap values)
- Border and radius values
- Shadow definitions
- Component styles (buttons, badges, cards, forms, tables)
- Full CSS variable definitions

Use this file as the source of truth for all design tokens and component patterns.

### `references/upgrade_element.md`

Admin page UI upgrade requirements including:
- Menu structure and file mapping
- UI element inventory by priority
- Page-specific style requirements
- Existing CSS file status
- Phase-based implementation plan
- Design token quick reference
- Implementation checklist

Use this file to understand the scope, prioritize work, and identify page-specific requirements.

## Tips for Success

1. **Start with common components**: Button, input, and table styles provide the biggest visual impact
2. **Use design tokens consistently**: Always reference CSS variables, never hardcode values
3. **Test incrementally**: Apply styles to one page at a time, verify before moving to the next
4. **Preserve functionality**: Focus on visual styles, avoid changing behavior or structure
5. **Document as you go**: Keep track of which pages have been upgraded
6. **Follow the phase plan**: Use the priority order in `references/upgrade_element.md` Section 6

## Common Pitfalls to Avoid

- ❌ Modifying `admin.css` directly
- ❌ Changing HTML class names in PHP files
- ❌ Hardcoding color or spacing values instead of using variables
- ❌ Breaking existing JavaScript by changing DOM structure
- ❌ Applying styles that conflict with mobile responsive layout
- ❌ Using overly specific selectors that can't be overridden later

## Success Criteria

A successful refactoring achieves:
- ✅ Consistent visual appearance matching Figma design system
- ✅ All existing functionality remains intact
- ✅ Layout structure preserved from `admin.css`
- ✅ Design tokens used throughout (no hardcoded values)
- ✅ Hover and focus states implemented
- ✅ No CSS conflicts or broken styles
- ✅ Changes documented and file paths provided to user
