---
name: schema-migration
description: "서로 다른 스키마의 테이블 간 데이터 마이그레이션을 자동화합니다. 필드 매핑, 여분 필드 할당, INSERT INTO SELECT 쿼리 생성을 수행합니다."
---

# Schema Migration Skill

서로 다른 스키마를 가진 테이블 간 데이터 마이그레이션을 자동화하는 스킬입니다.

## 트리거 조건

다음 키워드가 포함된 요청에서 이 스킬을 사용합니다:
- "테이블 마이그레이션"
- "스키마 마이그레이션"
- "데이터 이전"
- "테이블 데이터 복사"
- "DB 마이그레이션"

## 핵심 원칙

1. **INSERT INTO SELECT 사용** - 동일 DB 내 마이그레이션은 가장 효율적인 방식
2. **여분 필드 활용** - 매칭되지 않는 필드는 여분 필드(mb1~mb10 등)에 매핑
3. **문서화 필수** - 마이그레이션 결과를 `db_migration/result/`에 기록

## Workflow

### Step 1: 명세 확인

1. 원본 테이블 명세 파일 확인 (`db_migration/old/` 디렉토리)
2. 대상 테이블 스키마 확인 (MCP로 DESCRIBE 쿼리 실행)

```sql
-- 대상 테이블 구조 확인
DESCRIBE {target_table};

-- 기존 여분 필드 사용 현황 확인
SELECT mb1, mb2, mb3, mb4, mb5, mb6, mb7, mb8, mb9, mb10 
FROM {target_table} 
WHERE mb1 IS NOT NULL OR mb2 IS NOT NULL 
LIMIT 5;
```

### Step 2: 필드 매칭

필드를 매칭하는 3단계 로직:

#### 2.1 정확 매칭
컬럼명이 동일한 경우:
```
mem_email → mb_email (X - 다름)
email → email (O - 동일)
```

#### 2.2 의미 매칭
접두사/접미사 제거 후 핵심 단어 비교:

| 원본 | 대상 | 매칭 근거 |
|------|------|-----------|
| `mem_name` | `mb_name` | name 키워드 동일 |
| `mem_email` | `mb_email` | email 키워드 동일 |
| `mem_hp` | `mb_hp` | hp(휴대폰) 키워드 동일 |
| `mem_tel` | `mb_tel` | tel 키워드 동일 |
| `mem_addr` | `mb_addr1` | addr 키워드 동일 |
| `mem_post` | `mb_zip` | 우편번호 의미 동일 |
| `reg_date` | `mb_datetime` | 등록일/가입일 의미 동일 |

#### 2.3 타입 호환성 확인

| 원본 타입 | 대상 타입 | 호환 |
|-----------|-----------|------|
| varchar(n) | varchar(m) where m >= n | O |
| varchar | text | O |
| int | bigint | O |
| char | varchar | O |
| text | text | O |
| date | datetime | O (시간 부분 00:00:00) |
| datetime | date | O (시간 정보 손실) |

### Step 3: 여분 필드 할당

매칭되지 않는 필드는 여분 필드에 할당합니다.

참조: `references/spare-field-rules.md`

```
여분 필드 규칙:
- g5_member: mb1 ~ mb10
- g5_write_*: wr1 ~ wr10
- g5_shop_order: od1 ~ od10
- g5_shop_item: it1 ~ it10
```

### Step 4: 컬럼 추가 (필요 시)

여분 필드가 부족한 경우 ALTER TABLE로 컬럼 추가:

```sql
-- MCP execute_sql로 실행
ALTER TABLE {target_table} ADD COLUMN mb11 TEXT COMMENT '{원본_필드명}: {설명}';
ALTER TABLE {target_table} ADD COLUMN mb12 TEXT COMMENT '{원본_필드명}: {설명}';
```

### Step 5: 마이그레이션 쿼리 생성 및 실행

```sql
-- 데이터 마이그레이션
INSERT INTO {target_table} (
    -- 매칭된 필드
    mb_id, mb_name, mb_email, mb_hp,
    -- 여분 필드
    mb1, mb2, mb3, mb4, mb5
)
SELECT 
    -- 원본 필드
    mem_id, mem_name, mem_email, mem_hp,
    -- 여분 필드에 매핑
    mem_company_name, mem_company_part, birth_gubun, mem_company_tel, mem_company_fax
FROM {source_table}
WHERE NOT EXISTS (
    SELECT 1 FROM {target_table} WHERE mb_id = {source_table}.mem_id
);
```

### Step 6: 검증

```sql
-- 원본 테이블 건수
SELECT COUNT(*) as source_count FROM {source_table};

-- 대상 테이블 건수 (마이그레이션 후)
SELECT COUNT(*) as target_count FROM {target_table};
```

### Step 7: 결과 문서 생성

`db_migration/result/{target_table}.md` 파일 생성:

```markdown
# {target_table} 마이그레이션 결과

## 마이그레이션 정보

| 항목 | 값 |
|------|-----|
| 원본 테이블 | {source_table} |
| 대상 테이블 | {target_table} |
| 마이그레이션 일시 | {datetime} |
| 원본 건수 | {source_count} |
| 마이그레이션 건수 | {migrated_count} |

## 필드 매핑

| 원본 필드 | 대상 필드 | 매핑 유형 | 비고 |
|-----------|-----------|-----------|------|
| mem_id | mb_id | 의미 매칭 | 회원 아이디 |
| mem_name | mb_name | 의미 매칭 | 이름 |
| ... | ... | ... | ... |

## 여분 필드 사용 내역

| 여분 필드 | 원본 필드 | 원본 타입 | 설명 |
|-----------|-----------|-----------|------|
| mb1 | mem_company_name | varchar(50) | 회사명 |
| mb2 | mem_company_part | varchar(50) | 부서 |
| ... | ... | ... | ... |

## 추가된 컬럼

| 컬럼명 | 타입 | 원본 필드 | 설명 |
|--------|------|-----------|------|
| mb11 | TEXT | gradu_info_part | 졸업 학과명 |
| ... | ... | ... | ... |

## 실행된 쿼리

### ALTER TABLE (컬럼 추가)

```sql
ALTER TABLE {target_table} ADD COLUMN mb11 TEXT COMMENT 'gradu_info_part: 졸업 학과명';
```

### INSERT INTO SELECT (데이터 마이그레이션)

```sql
INSERT INTO {target_table} (...)
SELECT ... FROM {source_table};
```
```

## MCP 사용법

### MySQL MCP 서버

```
Server: user-MySQL_Server_changwon_fund_db
Tool: execute_sql
```

### 쿼리 실행 예시

```javascript
// 테이블 구조 확인
CallMcpTool({
  server: "user-MySQL_Server_changwon_fund_db",
  toolName: "execute_sql",
  arguments: { query: "DESCRIBE g5_member" }
})

// 데이터 마이그레이션
CallMcpTool({
  server: "user-MySQL_Server_changwon_fund_db",
  toolName: "execute_sql",
  arguments: { query: "INSERT INTO g5_member (...) SELECT ... FROM member_info" }
})
```

## 체크리스트

마이그레이션 실행 전:
- [ ] 원본 테이블 명세 확인
- [ ] 대상 테이블 구조 확인
- [ ] 기존 여분 필드 사용 현황 확인
- [ ] 필드 매핑 테이블 작성
- [ ] 여분 필드 할당 계획 수립

마이그레이션 실행:
- [ ] ALTER TABLE 실행 (필요 시)
- [ ] INSERT INTO SELECT 실행
- [ ] 건수 검증

마이그레이션 완료 후:
- [ ] 결과 문서 생성 (`db_migration/result/{table}.md`)
- [ ] 여분 필드 용도 문서화
- [ ] 추가 컬럼 COMMENT 확인

## 주의사항

1. **백업 필수**: 대상 테이블에 기존 데이터가 있다면 마이그레이션 전 백업
2. **중복 방지**: WHERE NOT EXISTS 조건으로 중복 삽입 방지
3. **트랜잭션**: 대량 데이터는 배치 단위로 처리 고려
4. **인코딩**: 원본/대상 테이블 문자셋 일치 확인 (UTF-8)
5. **NULL 처리**: 원본의 NULL 값이 대상 테이블 제약조건과 호환되는지 확인

## 파일 참조

- 원본 테이블 명세: `db_migration/old/`
- 여분 필드 규칙: `references/spare-field-rules.md`
- 마이그레이션 결과: `db_migration/result/`
